export type UserRole = 'public'|'team'|'admin';
export type UserProfile = { uid:string; email:string; firstName:string; lastName:string; username:string; age:number; role:UserRole; blocked?:boolean; selectedAccount?:string; createdAt?:unknown; depositMin?:number; depositMax?:number };
export const navItems = [
{ id:'overview', label:'Overview', group:'Workspace' },{ id:'roadmap',label:'13-Month Roadmap',group:'Workspace'},{id:'journal',label:'Learning Journal',group:'Workspace'},{id:'signals',label:'Signal Archive',group:'Research'},{id:'updates',label:'Updates & News',group:'Research'},{id:'community',label:'Community',group:'Connect'},{id:'reports',label:'Reports & Analytics',group:'Connect'},{id:'feedback',label:'Feedback & Complaints',group:'Connect'}
];
export const demoSignals = [{id:'s1',market:'FOREX · EUR/USD',direction:'Observation',status:'Demo / Active',time:'09:35 UTC',detail:'Example research card — not a live recommendation. Add your own educational notes.'},{id:'s2',market:'BINARY · Demo instrument',direction:'Observation',status:'Closed · Demo',time:'Yesterday',detail:'Archived example only. No entry, payout, or outcome is being recommended.'}];
