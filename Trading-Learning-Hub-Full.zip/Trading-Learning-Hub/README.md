# Trading Learning Hub — Full Project

Responsive React + TypeScript + Vite workspace for a 13-month educational roadmap and demo-learning journal. Includes Firebase Authentication integration, Firestore/Storage security rules, Firebase Hosting configuration, and a Cloud Functions starter.

**Start here:** read `SETUP.md` before using or deploying. The project is not live until Firebase is configured and security rules are deployed and tested. It is educational/demo-only and does not execute trades.

## Local start
```bat
npm install
copy .env.example .env
npm run dev
```

## Build
```bat
npm run build
```

The detailed roadmap source is in `src/data/roadmap.ts`. Do not use actual broker credentials or upload sensitive financial documents.
