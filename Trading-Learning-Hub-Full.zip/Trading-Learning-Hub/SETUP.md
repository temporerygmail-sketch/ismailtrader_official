# Trading Learning Hub — setup & security guide

This is a full-stack-ready React + TypeScript + Vite project with Firebase Auth/Firestore/Storage integration points, security rules, hosting configuration, a Cloud Functions starter, and a responsive UI. It is **not a live deployed service** until you create/configure a Firebase project, deploy rules, assign the first admin securely, and test every workflow.

## Important security notes
- A password was included in the original prompt. Treat it as exposed: change it anywhere it was used. It is deliberately not included in this project.
- Never put an admin password, service-account JSON, private key, or team invite secret in frontend code or `.env` values prefixed with `VITE_`.
- The product is an educational/demo journal and does not place trades. It is not a broker or investment service.
- All figures in the source plan are unverified assumptions. This app must not be used as a promise of profits or payout eligibility.

## 1. Install Node.js
Install a current Node.js LTS version. Open Command Prompt in this folder and run:

```bat
npm install
copy .env.example .env
npm run dev
```

Vite prints a local address, usually `http://localhost:5173`. Without Firebase configuration the cloud-auth screens intentionally show a setup warning.

## 2. Create a Firebase project
1. Open the official Firebase Console: https://console.firebase.google.com/
2. Create a project. Google Analytics is optional.
3. Add a Web App and copy its web configuration.
4. In Authentication → Sign-in method, enable Email/Password.
5. In Authentication → Settings → Authorized domains, add your eventual hosting domain.
6. In Firestore Database, create the database. Start in production mode.
7. In Storage, set up the bucket if you need evidence/media uploads.
8. Copy `.env.example` to `.env` and fill in the six `VITE_FIREBASE_*` values. Firebase web config is public by design; database/storage rules are what protect data.

## 3. Deploy rules and hosting
Install Firebase CLI: `npm install -g firebase-tools`, then run `firebase login`. Copy `.firebaserc.example` to `.firebaserc` and replace the project ID. Then:

```bat
npm run build
firebase deploy --only firestore:rules,storage,hosting
```

The `firebase.json` hosting target serves the built `dist` folder. For a custom domain, follow Firebase Hosting's console instructions; a domain name may cost money even if Firebase Hosting has a no-cost tier.

## 4. Set up the first admin securely
1. Register the intended admin email through the app and verify the email.
2. Open Firebase Console → Firestore → `users` collection → document ID equal to that account's Firebase Auth UID.
3. Change `role` to `admin` and `blocked` to `false` using the console while signed into the trusted owner account. Never allow public registration to choose `admin`.
4. Sign out and back in. The admin section is only rendered when the user's profile role is admin; Firestore rules separately enforce permissions.
5. If the admin account is ever compromised, revoke sessions/change its password and inspect audit records.

## 5. Team access code
The visible `NEXOVENTIA` text in the UI is **not a secure team credential** and does not grant team privileges. For secure self-service invites, deploy the callable Cloud Function in `functions/`. Cloud Functions deployment can require a billing-enabled Firebase plan, so a completely free deployment is not guaranteed.

```bat
cd functions
npm install
npm run build
cd ..
firebase functions:secrets:set TEAM_INVITE_CODE
```
Enter a long, unique secret at the prompt. Then deploy functions: `firebase deploy --only functions`. Enable App Check and configure it for your web app before relying on the function in production. Until then, the owner should promote approved team members manually in Firestore. Do not reuse the word `NEXOVENTIA` as the real secret.

## 6. Email verification and sender address
The app calls Firebase Authentication's `sendEmailVerification`. It verifies the user's email, but Firebase's default sender is not automatically your personal Gmail address. Custom branded sender delivery generally requires domain/DNS or an approved email delivery setup. Do not put Gmail passwords or SMTP credentials in frontend code.

## 7. What is implemented vs what still needs work
Implemented in source: responsive dashboard, 13 month sections, detailed tasks, locked task-completion writes, auth/verification flow, profile records, signals, updates, journal, community post UI, feedback/complaints, analytics/export, Firestore rules, Storage rules, Hosting config, and secure callable-function starter for team invite/member access.

Not yet production-verified: live Firebase credentials and deployment, full admin member-directory query, end-to-end uploads/voice/video, read-only public signal channels enforcement in UI, real-time chat moderation, all cross-device workflows, automated email templates from a branded sender, comprehensive audit trail, rate limiting/anti-spam, App Check rollout, accessibility audit, and browser/device acceptance testing. The UI should not be represented as proving those features work until configured and tested.

## 8. Security testing checklist
- Public signup cannot set role to team/admin or unblock itself.
- Unverified email cannot read/write protected data.
- Public user cannot read another user's private journal/report.
- Public user cannot create/update/delete signal or announcement records.
- Team user cannot change roles or access admin-only functions.
- Blocked user loses access to protected collections.
- Task completion cannot be deleted/unchecked by the member.
- Uploaded files are limited by path, size, and content type.
- Admin actions are audited.
- Test with separate public, team, admin, unverified, and blocked accounts.

## 9. Free hosting reality
Firebase Hosting, Authentication, and Firestore have no-cost quotas, but quotas and terms can change. Cloud Functions, outbound email customization, larger storage/traffic, and a custom domain may require billing or paid services. “No cost forever” cannot be guaranteed.
