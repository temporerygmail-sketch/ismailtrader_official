import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
initializeApp();
const db=getFirestore();
const TEAM_INVITE_CODE=defineSecret('TEAM_INVITE_CODE');

// Callable server-side check: the secret never ships to the browser. Deploying Cloud Functions may require a billing-enabled Firebase project.
export const redeemTeamInvite = onCall({secrets:[TEAM_INVITE_CODE],enforceAppCheck:true}, async (request)=>{
 if(!request.auth) throw new HttpsError('unauthenticated','Sign in first.');
 if(request.auth.token.email_verified!==true) throw new HttpsError('failed-precondition','Verify your email first.');
 const supplied=String(request.data?.code||'').trim();
 if(!supplied || supplied.length>100 || supplied!==TEAM_INVITE_CODE.value()) throw new HttpsError('permission-denied','Invite code is invalid.');
 const ref=db.doc(`users/${request.auth.uid}`); const snap=await ref.get();
 if(!snap.exists) throw new HttpsError('failed-precondition','Create your profile first.');
 if(snap.get('blocked')===true) throw new HttpsError('permission-denied','This account is blocked.');
 await ref.update({role:'team',updatedAt:FieldValue.serverTimestamp()});
 await db.collection('auditLogs').add({actorUid:request.auth.uid,action:'TEAM_INVITE_REDEEMED',targetUid:request.auth.uid,createdAt:FieldValue.serverTimestamp()});
 return {ok:true,role:'team'};
});

export const setMemberAccess = onCall({enforceAppCheck:true},async(request)=>{
 if(!request.auth) throw new HttpsError('unauthenticated','Sign in first.');
 const caller=await db.doc(`users/${request.auth.uid}`).get();
 if(!caller.exists || caller.get('role')!=='admin' || caller.get('blocked')===true) throw new HttpsError('permission-denied','Admin only.');
 const uid=String(request.data?.uid||''); const role=String(request.data?.role||''); const blocked=Boolean(request.data?.blocked);
 if(!uid || !['public','team'].includes(role)) throw new HttpsError('invalid-argument','Invalid target or role.');
 const target=db.doc(`users/${uid}`); if(!(await target.get()).exists) throw new HttpsError('not-found','Member not found.');
 await target.update({role,blocked,updatedAt:FieldValue.serverTimestamp()});
 await db.collection('auditLogs').add({actorUid:request.auth.uid,action:'MEMBER_ACCESS_CHANGED',targetUid:uid,role,blocked,createdAt:FieldValue.serverTimestamp()});
 return {ok:true};
});
